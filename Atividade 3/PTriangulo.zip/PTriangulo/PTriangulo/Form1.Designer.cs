﻿namespace PTriangulo
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            lblA = new Label();
            btnExecutar = new Button();
            lblB = new Label();
            lblC = new Label();
            btnSair = new Button();
            pictureBox1 = new PictureBox();
            btnLimpar = new Button();
            txtA = new TextBox();
            txtB = new TextBox();
            txtC = new TextBox();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            SuspendLayout();
            // 
            // lblA
            // 
            lblA.AutoSize = true;
            lblA.Location = new Point(34, 18);
            lblA.Name = "lblA";
            lblA.Size = new Size(94, 25);
            lblA.TabIndex = 0;
            lblA.Text = "Valor de A";
            // 
            // btnExecutar
            // 
            btnExecutar.Location = new Point(46, 257);
            btnExecutar.Name = "btnExecutar";
            btnExecutar.Size = new Size(112, 34);
            btnExecutar.TabIndex = 7;
            btnExecutar.Text = "Executar";
            btnExecutar.UseVisualStyleBackColor = true;
            btnExecutar.Click += btnExecutar_Click;
            // 
            // lblB
            // 
            lblB.AutoSize = true;
            lblB.Location = new Point(34, 69);
            lblB.Name = "lblB";
            lblB.Size = new Size(92, 25);
            lblB.TabIndex = 5;
            lblB.Text = "Valor de B";
            // 
            // lblC
            // 
            lblC.AutoSize = true;
            lblC.Location = new Point(34, 120);
            lblC.Name = "lblC";
            lblC.Size = new Size(93, 25);
            lblC.TabIndex = 6;
            lblC.Text = "Valor de C";
            // 
            // btnSair
            // 
            btnSair.Location = new Point(320, 257);
            btnSair.Name = "btnSair";
            btnSair.Size = new Size(112, 34);
            btnSair.TabIndex = 9;
            btnSair.Text = "Sair";
            btnSair.UseVisualStyleBackColor = true;
            btnSair.Click += btnSair_Click;
            // 
            // pictureBox1
            // 
            pictureBox1.BackgroundImage = (Image)resources.GetObject("pictureBox1.BackgroundImage");
            pictureBox1.BackgroundImageLayout = ImageLayout.Center;
            pictureBox1.Location = new Point(416, 27);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(313, 194);
            pictureBox1.TabIndex = 8;
            pictureBox1.TabStop = false;
            // 
            // btnLimpar
            // 
            btnLimpar.Location = new Point(183, 257);
            btnLimpar.Name = "btnLimpar";
            btnLimpar.Size = new Size(112, 34);
            btnLimpar.TabIndex = 8;
            btnLimpar.Text = "Limpar";
            btnLimpar.UseVisualStyleBackColor = true;
            btnLimpar.Click += btnLimpar_Click;
            // 
            // txtA
            // 
            txtA.Location = new Point(145, 18);
            txtA.Name = "txtA";
            txtA.Size = new Size(150, 31);
            txtA.TabIndex = 2;
            txtA.Validated += txtA_Validated;
            // 
            // txtB
            // 
            txtB.Location = new Point(145, 69);
            txtB.Name = "txtB";
            txtB.Size = new Size(150, 31);
            txtB.TabIndex = 3;
            txtB.Validated += txtB_Validated;
            // 
            // txtC
            // 
            txtC.Location = new Point(145, 120);
            txtC.Name = "txtC";
            txtC.Size = new Size(150, 31);
            txtC.TabIndex = 4;
            txtC.Validated += txtC_Validated;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(10F, 25F);
            AutoScaleMode = AutoScaleMode.Font;
            BackgroundImageLayout = ImageLayout.Center;
            ClientSize = new Size(762, 351);
            Controls.Add(txtC);
            Controls.Add(txtB);
            Controls.Add(txtA);
            Controls.Add(btnLimpar);
            Controls.Add(pictureBox1);
            Controls.Add(btnSair);
            Controls.Add(lblC);
            Controls.Add(lblB);
            Controls.Add(btnExecutar);
            Controls.Add(lblA);
            Name = "Form1";
            Text = "Form1";
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label lblA;
        private Button btnExecutar;
        private Label lblB;
        private Label lblC;
        private Button btnSair;
        private PictureBox pictureBox1;
        private Button btnLimpar;
        private TextBox txtA;
        private TextBox txtB;
        private TextBox txtC;
    }
}
