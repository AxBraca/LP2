namespace PTriangulo
{
    public partial class Form1 : Form
    {
        double a, b, c;
        public Form1()
        {
            InitializeComponent();
        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            txtA.Clear();
            txtB.Clear();
            txtC.Clear();
            a = 0;
            b = 0;
            c = 0;
        }

        private void btnExecutar_Click(object sender, EventArgs e)
        {
            if ((a < (b + c)) && (a > (Math.Abs(b - c)) && (b < (a + b)) && (b > (Math.Abs(a - c)))
                && (c < (a + b)) && (c > (Math.Abs(a - b)))))
            {
                if (a == b && b == c && a == c)
                {
                    MessageBox.Show("Triangulo equilatero");
                }
                else if (a == b || a == c || b == c)
                {
                    MessageBox.Show("Triangulo is�seles");
                }
                else
                    MessageBox.Show("Triangulo escaleno");
            }
            else
                MessageBox.Show("Esses valores n�o formam um triangulo");
        }


        private void txtA_Validated(object sender, EventArgs e)
        {
            if (this.ActiveControl == btnSair)
                return;

            if (!double.TryParse(txtA.Text, out a) || a == 0)
            {
                MessageBox.Show("valor invalido");
                txtA.Focus();
            }
        }

        private void txtB_Validated(object sender, EventArgs e)
        {
            if (this.ActiveControl == btnSair)
                return;

            if (!double.TryParse(txtB.Text, out b) || b == 0)
            {
                MessageBox.Show("valor invalido");
                txtB.Focus();
            }
        }

        private void txtC_Validated(object sender, EventArgs e)
        {
            if (this.ActiveControl == btnSair)
                return;

            if (!double.TryParse(txtC.Text, out c) || c == 0)
            {
                MessageBox.Show("valor invalido");
                txtC.Focus();
            }
        }
    }
}
