﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PCalc
{
    public partial class Form1 : Form
    {
        Double numero1, numero2, resultado;

        private void txtNum2_Validated(object sender, EventArgs e)
        {
            if (this.ActiveControl == btnFechar)
                return;

            if (!Double.TryParse(txtNum2.Text, out numero2))
                MessageBox.Show("Numero invalido");
        }

        private void btnMais_Click(object sender, EventArgs e)
        {
            resultado = numero1 + numero2;
            txtResultado.Text = resultado.ToString();
        }

        private void btnMenos_Click(object sender, EventArgs e)
        {
            resultado = numero1 - numero2;
            txtResultado.Text = resultado.ToString();
        }

        private void btnMultiplicacao_Click(object sender, EventArgs e)
        {
            resultado = numero1 * numero2;
            txtResultado.Text = resultado.ToString();
        }

        private void btnDivisao_Click(object sender, EventArgs e)
        {
            resultado = numero1 / numero2;
            txtResultado.Text = resultado.ToString("F2");
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            txtNum1.Clear();
            txtNum2.Clear();
            txtResultado.Clear();
            numero1 = 0;
            numero2 = 0;    
            resultado = 0;
            txtNum1.Focus();
        }

        private void btnFechar_Click(object sender, EventArgs e)
        {
            Close();
        }

        public Form1()
        {
            InitializeComponent();
        }

        private void txtNum1_Validated(object sender, EventArgs e)
        {
            if (this.ActiveControl == btnFechar)
                return;

            if (!Double.TryParse(txtNum1.Text, out numero1))
                MessageBox.Show("Numero invalido");

        }
    }
}
