namespace PAtv5
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void exercic�o1ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmExercicio1 FrmExercicio1 = new frmExercicio1();
            FrmExercicio1.MdiParent = this;
            FrmExercicio1.WindowState = FormWindowState.Maximized;
            FrmExercicio1.Show();
        }

        private void exercic�o2ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmExercicio2 FrmExercicio2 = new frmExercicio2();
            FrmExercicio2.MdiParent = this;
            FrmExercicio2.WindowState = FormWindowState.Maximized;
            FrmExercicio2.Show();
        }

        private void exercic�o3ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmExercicio3 FrmExercicio3 = new frmExercicio3();
            FrmExercicio3.MdiParent = this;
            FrmExercicio3.WindowState = FormWindowState.Maximized;
            FrmExercicio3.Show();
        }

        private void exercic�o4ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmExercicio4 FrmExercicio4 = new frmExercicio4();
            FrmExercicio4.MdiParent = this;
            FrmExercicio4.WindowState = FormWindowState.Maximized;
            FrmExercicio4.Show();
        }

        private void sairToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}
