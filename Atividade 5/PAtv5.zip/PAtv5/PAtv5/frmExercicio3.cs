﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Runtime.Intrinsics.Arm;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PAtv5
{
    public partial class frmExercicio3 : Form
    {
        public frmExercicio3()
        {
            InitializeComponent();
        }

        private void btnPalindromo_Click(object sender, EventArgs e)
        {
            txtFrase.Text = txtFrase.Text.ToLower().Replace(" ", "");
            char[] vetor = txtFrase.Text.ToCharArray();
            Array.Reverse(vetor);

            string auxiliar = new string(vetor);
            

            if (auxiliar == txtFrase.Text)
            {
                txtResposta.Text = "Sim";
            }
            else
            {
                txtResposta.Text = "Não";
            }
        }
    }
}
