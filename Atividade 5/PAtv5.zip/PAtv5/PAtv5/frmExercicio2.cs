﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PAtv5
{
    public partial class frmExercicio2 : Form
    {
        int n,h;

        public frmExercicio2()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e) // esqueci de mudar o nome do botao e fica dando problema no forms inteiro quando tento resolver :(
        {
        
            for (int i = n; i > 0; i--)
            {                
                h += (1/i--);
                i--;
            }

            txtN.Text = h.ToString();

        }

        private void txtN_Validated(object sender, EventArgs e)
        {
            if (!int.TryParse(txtN.Text, out n) || (n == 0))
            {
                MessageBox.Show("numero invalido");
                txtN.Focus();
            }
        }
    }
}
