﻿namespace PAtv5
{
    partial class frmExercicio2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            txtN = new TextBox();
            textBox2 = new TextBox();
            lbl1 = new Label();
            button1 = new Button();
            SuspendLayout();
            // 
            // txtN
            // 
            txtN.Location = new Point(284, 121);
            txtN.Name = "txtN";
            txtN.Size = new Size(100, 23);
            txtN.TabIndex = 0;
            txtN.Validated += txtN_Validated;
            // 
            // textBox2
            // 
            textBox2.Location = new Point(284, 276);
            textBox2.Name = "textBox2";
            textBox2.ReadOnly = true;
            textBox2.Size = new Size(100, 23);
            textBox2.TabIndex = 1;
            // 
            // lbl1
            // 
            lbl1.AutoSize = true;
            lbl1.Location = new Point(225, 89);
            lbl1.Name = "lbl1";
            lbl1.Size = new Size(218, 15);
            lbl1.TabIndex = 2;
            lbl1.Text = "Forneça um numero inteiro maior que 0";
            // 
            // button1
            // 
            button1.Location = new Point(271, 220);
            button1.Name = "button1";
            button1.Size = new Size(126, 40);
            button1.TabIndex = 3;
            button1.Text = "Gerar numero";
            button1.UseVisualStyleBackColor = true;
            button1.Click += button1_Click;
            // 
            // frmExercicio2
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(686, 409);
            Controls.Add(button1);
            Controls.Add(lbl1);
            Controls.Add(textBox2);
            Controls.Add(txtN);
            Name = "frmExercicio2";
            Text = "frmExercicio2";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private TextBox txtN;
        private TextBox textBox2;
        private Label lbl1;
        private Button button1;
    }
}