﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PAtv5
{
    public partial class frmExercicio1 : Form
    {
        public frmExercicio1()
        {
            InitializeComponent();

        }

        private void btnSpace_Click(object sender, EventArgs e)
        {
            string text = rctxt.Text;
            int countSpace = 0;

            for (int i = 0; i < text.Length; i++)
            {
                if (text[i] == ' ') { countSpace++; }
            }

            txtSpace.Text = countSpace.ToString();
        }
        

        private void btnR_Click_1(object sender, EventArgs e)
        {
            string text = rctxt.Text;
            int countR = 0;

            foreach (char c in text)
            {
                if (c == 'r' || c == 'R')
                {
                    countR++;
                }

            }

            txtR.Text = countR.ToString();
        }

        private void btnSS_Click_1(object sender, EventArgs e)
        {
            string text = rctxt.Text;
            int countSame = 0;

            if (text.Length > 1)
            {
                int i = 0;
                do
                {
                    if (char.IsLetter(text[i]) && text[i] == text[i + 1])
                    {
                        countSame++;
                    }
                    i++;
                } while (i < text.Length - 1);
            }

            txtSS.Text = countSame.ToString();
        }
    }
}

