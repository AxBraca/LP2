﻿namespace PAtv5
{
    partial class frmExercicio1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            txtSS = new TextBox();
            txtR = new TextBox();
            txtSpace = new TextBox();
            btnSS = new Button();
            btnR = new Button();
            btnSpace = new Button();
            lblCalc = new Label();
            lblinstrucao = new Label();
            rctxt = new RichTextBox();
            SuspendLayout();
            // 
            // txtSS
            // 
            txtSS.Location = new Point(615, 327);
            txtSS.Name = "txtSS";
            txtSS.ReadOnly = true;
            txtSS.Size = new Size(100, 23);
            txtSS.TabIndex = 17;
            // 
            // txtR
            // 
            txtR.Location = new Point(350, 327);
            txtR.Name = "txtR";
            txtR.ReadOnly = true;
            txtR.Size = new Size(100, 23);
            txtR.TabIndex = 16;
            // 
            // txtSpace
            // 
            txtSpace.Location = new Point(85, 327);
            txtSpace.Name = "txtSpace";
            txtSpace.ReadOnly = true;
            txtSpace.Size = new Size(100, 23);
            txtSpace.TabIndex = 15;
            // 
            // btnSS
            // 
            btnSS.Location = new Point(615, 264);
            btnSS.Name = "btnSS";
            btnSS.Size = new Size(100, 57);
            btnSS.TabIndex = 14;
            btnSS.Text = "Instancias de mesmo para de letras";
            btnSS.UseVisualStyleBackColor = true;
            btnSS.Click += btnSS_Click_1;
            // 
            // btnR
            // 
            btnR.Location = new Point(350, 264);
            btnR.Name = "btnR";
            btnR.Size = new Size(100, 57);
            btnR.TabIndex = 13;
            btnR.Text = "Instancias de \"R\"";
            btnR.UseVisualStyleBackColor = true;
            btnR.Click += btnR_Click_1;
            // 
            // btnSpace
            // 
            btnSpace.Location = new Point(85, 264);
            btnSpace.Name = "btnSpace";
            btnSpace.Size = new Size(100, 57);
            btnSpace.TabIndex = 12;
            btnSpace.Text = "Instancias de ' '";
            btnSpace.UseVisualStyleBackColor = true;
            btnSpace.Click += btnSpace_Click;
            // 
            // lblCalc
            // 
            lblCalc.AutoSize = true;
            lblCalc.Location = new Point(377, 235);
            lblCalc.Name = "lblCalc";
            lblCalc.Size = new Size(46, 15);
            lblCalc.TabIndex = 11;
            lblCalc.Text = "Calcule";
            // 
            // lblinstrucao
            // 
            lblinstrucao.AutoSize = true;
            lblinstrucao.Location = new Point(275, 100);
            lblinstrucao.Name = "lblinstrucao";
            lblinstrucao.Size = new Size(251, 15);
            lblinstrucao.TabIndex = 10;
            lblinstrucao.Text = "Escreva um texto de nomaximo 100 caracteres";
            // 
            // rctxt
            // 
            rctxt.Location = new Point(85, 125);
            rctxt.Name = "rctxt";
            rctxt.Size = new Size(631, 96);
            rctxt.TabIndex = 9;
            rctxt.Text = "";
            // 
            // frmExercicio1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(txtSS);
            Controls.Add(txtR);
            Controls.Add(txtSpace);
            Controls.Add(btnSS);
            Controls.Add(btnR);
            Controls.Add(btnSpace);
            Controls.Add(lblCalc);
            Controls.Add(lblinstrucao);
            Controls.Add(rctxt);
            Name = "frmExercicio1";
            Text = "frmExercicio1";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private TextBox txtSS;
        private TextBox txtR;
        private TextBox txtSpace;
        private Button btnSS;
        private Button btnR;
        private Button btnSpace;
        private Label lblCalc;
        private Label lblinstrucao;
        private RichTextBox rctxt;
    }
}