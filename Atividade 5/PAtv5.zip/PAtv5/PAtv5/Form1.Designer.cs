﻿namespace PAtv5
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            menuStrip1 = new MenuStrip();
            exercicío1ToolStripMenuItem = new ToolStripMenuItem();
            exercicío2ToolStripMenuItem = new ToolStripMenuItem();
            exercicío3ToolStripMenuItem = new ToolStripMenuItem();
            exercicío4ToolStripMenuItem = new ToolStripMenuItem();
            sairToolStripMenuItem = new ToolStripMenuItem();
            menuStrip1.SuspendLayout();
            SuspendLayout();
            // 
            // menuStrip1
            // 
            menuStrip1.Items.AddRange(new ToolStripItem[] { exercicío1ToolStripMenuItem, exercicío2ToolStripMenuItem, exercicío3ToolStripMenuItem, exercicío4ToolStripMenuItem, sairToolStripMenuItem });
            menuStrip1.Location = new Point(0, 0);
            menuStrip1.Name = "menuStrip1";
            menuStrip1.Size = new Size(800, 24);
            menuStrip1.TabIndex = 0;
            menuStrip1.Text = "menuStrip1";
            // 
            // exercicío1ToolStripMenuItem
            // 
            exercicío1ToolStripMenuItem.Name = "exercicío1ToolStripMenuItem";
            exercicío1ToolStripMenuItem.Size = new Size(75, 20);
            exercicío1ToolStripMenuItem.Text = "Exercicío 1";
            exercicío1ToolStripMenuItem.Click += exercicío1ToolStripMenuItem_Click;
            // 
            // exercicío2ToolStripMenuItem
            // 
            exercicío2ToolStripMenuItem.Name = "exercicío2ToolStripMenuItem";
            exercicío2ToolStripMenuItem.Size = new Size(75, 20);
            exercicío2ToolStripMenuItem.Text = "Exercicío 2";
            exercicío2ToolStripMenuItem.Click += exercicío2ToolStripMenuItem_Click;
            // 
            // exercicío3ToolStripMenuItem
            // 
            exercicío3ToolStripMenuItem.Name = "exercicío3ToolStripMenuItem";
            exercicío3ToolStripMenuItem.Size = new Size(75, 20);
            exercicío3ToolStripMenuItem.Text = "Exercicío 3";
            exercicío3ToolStripMenuItem.Click += exercicío3ToolStripMenuItem_Click;
            // 
            // exercicío4ToolStripMenuItem
            // 
            exercicío4ToolStripMenuItem.Name = "exercicío4ToolStripMenuItem";
            exercicío4ToolStripMenuItem.Size = new Size(75, 20);
            exercicío4ToolStripMenuItem.Text = "Exercicío 4";
            exercicío4ToolStripMenuItem.Click += exercicío4ToolStripMenuItem_Click;
            // 
            // sairToolStripMenuItem
            // 
            sairToolStripMenuItem.Name = "sairToolStripMenuItem";
            sairToolStripMenuItem.Size = new Size(37, 20);
            sairToolStripMenuItem.Text = "sair";
            sairToolStripMenuItem.Click += sairToolStripMenuItem_Click;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(menuStrip1);
            IsMdiContainer = true;
            MainMenuStrip = menuStrip1;
            Name = "Form1";
            Text = "Form1";
            menuStrip1.ResumeLayout(false);
            menuStrip1.PerformLayout();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private MenuStrip menuStrip1;
        private ToolStripMenuItem exercicío1ToolStripMenuItem;
        private ToolStripMenuItem sairToolStripMenuItem;
        private ToolStripMenuItem exercicío2ToolStripMenuItem;
        private ToolStripMenuItem exercicío3ToolStripMenuItem;
        private ToolStripMenuItem exercicío4ToolStripMenuItem;
    }
}
