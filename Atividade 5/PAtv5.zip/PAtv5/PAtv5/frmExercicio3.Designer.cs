﻿namespace PAtv5
{
    partial class frmExercicio3
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            txtFrase = new TextBox();
            btnPalindromo = new Button();
            txtResposta = new TextBox();
            SuspendLayout();
            // 
            // txtFrase
            // 
            txtFrase.Location = new Point(52, 63);
            txtFrase.Name = "txtFrase";
            txtFrase.Size = new Size(629, 23);
            txtFrase.TabIndex = 0;
            // 
            // btnPalindromo
            // 
            btnPalindromo.Location = new Point(266, 153);
            btnPalindromo.Name = "btnPalindromo";
            btnPalindromo.Size = new Size(163, 23);
            btnPalindromo.TabIndex = 1;
            btnPalindromo.Text = "É palindromo?";
            btnPalindromo.UseVisualStyleBackColor = true;
            btnPalindromo.Click += btnPalindromo_Click;
            // 
            // txtResposta
            // 
            txtResposta.Location = new Point(300, 182);
            txtResposta.Name = "txtResposta";
            txtResposta.ReadOnly = true;
            txtResposta.Size = new Size(100, 23);
            txtResposta.TabIndex = 2;
            // 
            // frmExercicio3
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(txtResposta);
            Controls.Add(btnPalindromo);
            Controls.Add(txtFrase);
            Name = "frmExercicio3";
            Text = "frmExercicio3";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private TextBox txtFrase;
        private Button btnPalindromo;
        private TextBox txtResposta;
    }
}