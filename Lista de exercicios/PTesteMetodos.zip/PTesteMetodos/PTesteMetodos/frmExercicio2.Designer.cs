﻿namespace PTesteMetodos
{
    partial class frmExercicio2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            txtPalavra1 = new TextBox();
            txtPalavra2 = new TextBox();
            lblPalavra1 = new Label();
            lblPalavra2 = new Label();
            btnCompara = new Button();
            btnInserir1 = new Button();
            btnInserir2 = new Button();
            SuspendLayout();
            // 
            // txtPalavra1
            // 
            txtPalavra1.Location = new Point(165, 34);
            txtPalavra1.Name = "txtPalavra1";
            txtPalavra1.Size = new Size(412, 31);
            txtPalavra1.TabIndex = 0;
            // 
            // txtPalavra2
            // 
            txtPalavra2.Location = new Point(165, 106);
            txtPalavra2.Name = "txtPalavra2";
            txtPalavra2.Size = new Size(412, 31);
            txtPalavra2.TabIndex = 1;
            // 
            // lblPalavra1
            // 
            lblPalavra1.AutoSize = true;
            lblPalavra1.Location = new Point(27, 40);
            lblPalavra1.Name = "lblPalavra1";
            lblPalavra1.Size = new Size(82, 25);
            lblPalavra1.TabIndex = 2;
            lblPalavra1.Text = "Palavra 1";
            // 
            // lblPalavra2
            // 
            lblPalavra2.AutoSize = true;
            lblPalavra2.Location = new Point(27, 112);
            lblPalavra2.Name = "lblPalavra2";
            lblPalavra2.Size = new Size(82, 25);
            lblPalavra2.TabIndex = 3;
            lblPalavra2.Text = "Palavra 2";
            // 
            // btnCompara
            // 
            btnCompara.Location = new Point(27, 229);
            btnCompara.Name = "btnCompara";
            btnCompara.Size = new Size(150, 74);
            btnCompara.TabIndex = 5;
            btnCompara.Text = "Compara";
            btnCompara.UseVisualStyleBackColor = true;
            // 
            // btnInserir1
            // 
            btnInserir1.Location = new Point(227, 229);
            btnInserir1.Name = "btnInserir1";
            btnInserir1.Size = new Size(150, 74);
            btnInserir1.TabIndex = 6;
            btnInserir1.Text = "Inserir 1 no meio do 2";
            btnInserir1.UseVisualStyleBackColor = true;
            // 
            // btnInserir2
            // 
            btnInserir2.Location = new Point(427, 229);
            btnInserir2.Name = "btnInserir2";
            btnInserir2.Size = new Size(150, 74);
            btnInserir2.TabIndex = 7;
            btnInserir2.Text = "Inserir ** no meio do 1";
            btnInserir2.UseVisualStyleBackColor = true;
            // 
            // frmExercicio2
            // 
            AutoScaleDimensions = new SizeF(10F, 25F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(642, 342);
            Controls.Add(btnInserir2);
            Controls.Add(btnInserir1);
            Controls.Add(btnCompara);
            Controls.Add(lblPalavra2);
            Controls.Add(lblPalavra1);
            Controls.Add(txtPalavra2);
            Controls.Add(txtPalavra1);
            Name = "frmExercicio2";
            Text = "frmExercicio2";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private TextBox txtPalavra1;
        private TextBox txtPalavra2;
        private Label lblPalavra1;
        private Label lblPalavra2;
        private Button btnCompara;
        private Button btnInserir1;
        private Button btnInserir2;
    }
}