﻿using Microsoft.VisualBasic;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PNotebook01
{
    public partial class Form1 : Form
    {
        double[,] notebooks = new double[3, 3];
        public Form1()
        {
            InitializeComponent();
        }

        private void btnExecutar_Click(object sender, EventArgs e)
        {
            double mediaGeral = 0;
            string aux = "";

            for (int i = 0; i < notebooks.GetLength(0); i++)
            {
                for (int j = 0; j < notebooks.GetLength(1); j++)
                {
                    aux = Interaction.InputBox($"Notebook {i + 1}: Loja {j + 1} ", "Entrada de dados");
                    if (!double.TryParse(aux, out notebooks[i, j]) || notebooks[i,j]<=0)
                    {
                        MessageBox.Show("valor invalido");
                        j--;
                    }           

                } 
            }

            for (int i = 0; i < notebooks.GetLength(0); i++)
            {
                double media;
                media = (notebooks[i,0] + notebooks[i,1] + notebooks[i,2]) / 3;
                mediaGeral += media;
                lstbxListaPrecos.Items.Add($"Notebook: {i + 1} Loja:1 R$: {Math.Round(notebooks[i, 0], 2)}     " +
                    $"Loja:2 R$: {Math.Round(notebooks[i,1],2)}    Loja:3 R$: {Math.Round(notebooks[i,2],2)}    " +
                    $"Média: R$: {Math.Round(media, 2)}");

            }
            mediaGeral = mediaGeral / 3;
            lstbxListaPrecos.Items.Add("-------------------------------------------------------------------");
            lstbxListaPrecos.Items.Add($"Média Geral Computadores: R$: {Math.Round(mediaGeral, 2)}");
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            lstbxListaPrecos.Items.Clear();
        }
    }
}
